
   <!-- body -->
   <body class="main-layout">
     
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="{{url('public')}}/assets/images/logo.png" alt="#" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item ">
                                 <a class="nav-link" href="{{url('shop')}}">Produk</a>
                              </li>
                             
                             <li class="nav-item">
                             <a class="nav-link" href="{{url('login')}}" >Login</a>
                           </li>
                            <li class="nav-item">
                             <a class="nav-link" href="{{url('checkout')}}" > <i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                           </li>

                        </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- end header inner -->
      <!-- end header -->

     

    
      
      <!-- products -->
   
                       

      
      <!-- end footer --> <script src="{{url('public')}}/assets/js/jquery.min.js"></script>
      <script src="{{url('public')}}/assets/js/popper.min.js"></script>
      <script src="{{url('public')}}/assets/js/bootstrap.bundle.min.js"></script>
      <script src="{{url('public')}}/assets/js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="{{url('public')}}/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="{{url('public')}}/assets/js/custom.js"></script>
      <!-- Javascript files-->
     
   </body>
</html>

