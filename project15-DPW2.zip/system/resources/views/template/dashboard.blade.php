@extends('template.base')

@section('content')
  <div class="container">
    <div class="col-md-12 mt-5">
      <div class="card">
        <div class="card-header">
          <h3>Halaman Beranda</h3>
        </div>
        <div class="card-body">

        </div>
      </div>
    </div>
  </div>
@endsection