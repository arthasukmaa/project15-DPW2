<?php if($errors->has($item)): ?>
    <?php $__currentLoopData = $errors->get($item); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label for="" class="text-danger"> *<?php echo e($msg); ?></label>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\project15-DPW2\system\resources\views/template/utils/errors.blade.php ENDPATH**/ ?>