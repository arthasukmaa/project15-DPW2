<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="card mt-3 pt-3">
    <div class="row ml-1 mr-2 mb-3">
      <h4>Detail Data User</h4>
    </div>

           
              <div class="card-body">
                <h3><?php echo e($user->nama); ?></h3>
                <hr>
                <p><?php echo e("@".$user->username); ?> 
                  <hr>
                  Email : <?php echo e($user->email); ?> 
                
                </p>
                <p>
                
                  No handphone : <?php echo e($user->detail->no_handphone); ?> 
                
                </p>
  
              </div>
            </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project15-DPW2\system\resources\views/template/user/show.blade.php ENDPATH**/ ?>