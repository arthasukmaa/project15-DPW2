<?php $timeService = app('App\Services\TimeServices'); ?>



<?php $__env->startSection('content'); ?>

  <div class="container">
  <div class="row mt-5">
    <div class="col-md-12">
      <div class="card">
         </div class="card-header">
         <div class="col-md-10">
                  <h3>Filter</h3>
                </div>
                <div class="col-md-2">
                  <div class="float-right">
                   Jam : <?php echo e($timeService->showTimeNow()); ?>

                  </div>
                </div>
              
              <div class="card-body">
                <form action="<?php echo e(url('admin/produk/filter')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label for="" class="control-label">Nama</label>
                    <input type="text" class="form-control" name="nama" value="<?php echo e($nama ?? ""); ?>">
                    </div>
                    <div class="form-group">
                    <label for="" class="control-label">stok</label>
                    <input type="text" class="form-control" name="stok" value="<?php echo e($stok ?? ""); ?>">
                    </div>
                    <div class="row">
              <div class="col-md-6">
                <div class="form-group">
              <label for="" class="control-label"> Harga Min</label>
              <input type="text" class="form-control" name="harga_min" value="<?php echo e($harga_min ?? ""); ?>">
            </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
              <label for="" class="control-label"> Harga Max</label>
              <input type="text" class="form-control" name="harga_max" value="<?php echo e($harga_max ?? ""); ?>">
            </div>
              </div>
                  <div class="col-md-6">
                  <button class="btn btn-primary float-right"><i class="fa fa-search" data-feather="search"></i> Filter</button>
                </form>
              </div>
              </div>
              </div>
              <div class="row">
                <div class="col-md-10">
                  <h3>Data Produk</h3>
                </div>
                <div class="col-md-2">
                  <a href="<?php echo e(url('admin/produk/create')); ?>" class="btn btn-primary float-right"><i class="fa fa-plus" data-feather="plus"></i> Data Produk</a>
                </div>
                <?php echo $__env->make('template.utils.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card-body">
                  <table class="table">
                    <thead>
                      <th>No</th>
                      <th>Aksi</th>
                      <th>Nama</th>
                      <th>Stok</th>
                      <th>Harga</th>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $list_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                          <div class="btn-group">
                          <a href="<?php echo e(url('admin/produk', $produk->uuid)); ?>" class="btn btn-primary" ><i  class="fa fa-info" data-feather="info"></i></a>
                          <a href="<?php echo e(url('admin/produk', $produk->uuid)); ?>/edit" class="btn btn-warning"><i class="fa fa-edit"data-feather="edit" ></i></a>
                          <?php echo $__env->make('template.utils.delete', ['url' => url('admin/produk', $produk->uuid)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                        </td>
                        <td><?php echo e($produk->nama); ?></td>
                        <td><?php echo e($produk->stok); ?></td>
                        <td><?php echo e($produk->harga); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
         </div>
      </div>  
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project15-DPW2\system\resources\views/template/produk/index.blade.php ENDPATH**/ ?>