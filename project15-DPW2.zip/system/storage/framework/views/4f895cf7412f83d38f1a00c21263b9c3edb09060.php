<form action="<?php echo e($url); ?>" method="post" class="form-inline" onsubmit="return confirm('Yakin Akan Menghapus Data Ini?')">
	<?php echo csrf_field(); ?>
 	<?php echo method_field("delete"); ?>
  <button class="btn btn-danger"><i class="fa fa-trash"data-feather="trash"></i></button>
</form><?php /**PATH C:\xampp\htdocs\project15-DPW2\system\resources\views/template/utils/delete.blade.php ENDPATH**/ ?>