<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-5">
                <div class="card">
                    <div class="card-header">
                        Tambah Data user
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('admin/user')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="" class="control-label">Nama</label>
                                <?php echo $__env->make('template.utils.errors', ['item' => 'nama'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <input type="text" class="form-control" name="nama">
                            </div>

                            <div class="form-group">
                                <label for="" class="control-label">Username</label>
                                <?php echo $__env->make('template.utils.errors', ['item' => 'username'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <input type="text" class="form-control" name="username">
                            </div>

                            <div class="form-group">
                                <label for="" class="control-label">Jenis kelamin</label>
                                <?php echo $__env->make('template.utils.errors', ['item' => 'jenis_kelamin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <input type="text" class="form-control" name="jenis_kelamin">
                            </div>


                            <div class="form-group">
                                <label for="" class="control-label">Email</label>
                                <?php echo $__env->make('template.utils.errors', ['item' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <input type="email" class="form-control" name="email">
                            </div>

                            <div class="form-group">
                                <label for="" class="control-label">password</label>
                                <?php echo $__env->make('template.utils.errors', ['item' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <input type="password" class="form-control" name="password">
                            </div>
                            
                            <div class="form-group">
                                <label for="" class="control-label">No Hp</label>
                                <?php echo $__env->make('template.utils.errors', ['item' => 'no_handphone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <input type="text" class="form-control" name="no_handphone">
                            </div>

                            <button class="btn btn-dark float-right"><i class="fa fa-save"></i> Simpan</button>
                        </form>
                    </div>
                </div>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project15-DPW2\system\resources\views/template/user/create.blade.php ENDPATH**/ ?>