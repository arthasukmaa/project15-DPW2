<?php $__env->startSection('content'); ?>
<!-- start coding -->

   
  <div class="container">
  <div class="row mt-5">
    <div class="col-md-12">
      <div class="card">
         </div class="card-header">
              <div class="row">
                <div class="col-md-6">
                  <h3> Detail Data Produk</h3>
                </div>

    <div class="container">
      <div class="card-body">
        <h3><?php echo e($produk->nama); ?></h3>
            <hr>
            <p><?php echo e($produk->harga); ?> |
   Stok : <?php echo e($produk->stok); ?> |
   Tanggal Produk : <?php echo e($produk->created_at->format("d M Y")); ?>

</p>
             <p>
                <?php echo nl2br ($produk->Deskripsi); ?>

             </p>
            <p>
               <img src="<?php echo e(url("public/$produk->foto")); ?>" alt="<?php echo e($produk->foto); ?>" width="50%">
            </p>
        </div>  
      </div>
      
    </div>

    </div>
   </div>

<!-- end coding -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make("template.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project15-DPW2\system\resources\views/template/produk/show.blade.php ENDPATH**/ ?>