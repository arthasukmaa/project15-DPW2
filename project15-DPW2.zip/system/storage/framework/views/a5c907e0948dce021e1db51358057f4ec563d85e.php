<!DOCTYPE html>
<html lang="en">

<head>
	
	<link rel="canonical" href="https://demo-basic.adminkit.io/" />

	<title>Admin</title>

	<?php echo $__env->make("template.section.assets", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
	<div class="wrapper">
		<?php echo $__env->make("template.section.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="main">
			<?php echo $__env->make("template.section.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<main class="content">
				<div class="container-fluid p-0">
					<?php echo $__env->make('template.utils.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php echo $__env->yieldContent('content'); ?>
					
				</div>
			</main>

			<?php echo $__env->make("template.section.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>

	<?php echo $__env->make("template.section.js", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\project15-DPW2\system\resources\views/template/base.blade.php ENDPATH**/ ?>