<?php $__currentLoopData = ['success', 'danger', 'warning',]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if(session($status)): ?>
		<div class="alert alert-<?php echo e($status); ?> alert-dismissable custom-<?php echo e($status); ?>-box">
			<a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		</div>
		<strong> <?php echo e(session($status)); ?></strong>
	<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\project15-DPW2\system\resources\views/template/utils/notif.blade.php ENDPATH**/ ?>